
# AI Music API - Vercel 部署版

这是一个使用 Vercel 部署的 AI 音乐生成 API，用于中转 Deepinfra 的 MusicGen 接口，避免在前端暴露 API Key。

## 使用方式

### 前端请求：

```javascript
const response = await fetch("https://ai-music-api.vercel.app/api/generate-music", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ prompt: "a relaxing lofi melody" })
});
const data = await response.json();
```

## 环境变量

你需要在 Vercel 的项目设置中添加环境变量：

- `DEEPINFRA_API_KEY`：你的 Deepinfra 密钥
